package com.kitri.lang;

public class ReverseTest {

	public static void main(String[] args) {

//		Hello Java !!! 3���� �����

//		1. 
		String str = "!!! avaJ olleH";
		String rev = "";
		
		char c[] = str.toCharArray();
		int len = c.length;
		for (int i = len - 1; i >= 0; i--) {
			rev += c[i];
		}
		System.out.println(rev);
		int x = rev.indexOf('e');
		System.out.println("e�� "+ (x+1) +"��°�̴�.");
		System.out.println("------------------");
		
//		2.
		

		String str2 = "!!! avaJ olleH";
		rev="";
		len = str2.length();
		for (int i = len - 1; i >= 0; i--) {
			rev += str.charAt(i);
		}
		
		System.out.println(rev);
		System.out.println("e�� "+ (x+1) +"��°�̴�.");
		System.out.println("------------------");

//		3. Hello Java !!!
		String str3 = "!!! avaJ olleH";
		byte b[] = str3.getBytes();
		rev = "";
		len = str3.length();
		for (int i = len - 1; i >= 0; i--) {
			byte b2[] = { b[i] };
			String str4 = new String(b2);
			rev += str4;
		}

		System.out.println(rev);
		System.out.println("e��" + (x+1)+ "��°�̴�.");
		System.out.println("------------------");
		System.out.println("");
//		e�� 2��° �ֽ��ϴ�. e�� ~��° �ֽ��ϴ�.

//		1.

	}
}
